# FARIS STUDIO (v0.2.0)

Dark, tablet/phone adaptive photo editor.
Working: open image, zoom/pan/rotate view, layers (Layer + Background, add/delete/hide),
Brush / Eraser / Shape / Text / Picker on drawing layers, filters (14 looks), adjustments
(brightness, contrast, saturation, hue), vignette, undo/redo, PNG export (Pictures/FarisStudio).
Not yet (shown dimmed): Select, Move, Crop, Magic Wand, Fill, Sticker.

Build: GitHub Actions (.github/workflows/build.yml) or Android Studio (JDK 17, Gradle 8.7).
