package com.faris.studio.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PanelBg = Color(0xFF161F33)
val BarBg = Color(0xFF111A2D)
val CanvasBg = Color(0xFF0B1220)
val Accent = Color(0xFF1E7BFF)
val Selected = Color(0xFF1B5ED6)
val TextDim = Color(0xFF9AA7BD)

private val Scheme = darkColorScheme(
    primary = Accent,
    background = CanvasBg,
    surface = PanelBg,
    onSurface = Color(0xFFE9EEF8),
    onBackground = Color(0xFFE9EEF8),
    surfaceVariant = BarBg
)

@Composable
fun FarisTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
