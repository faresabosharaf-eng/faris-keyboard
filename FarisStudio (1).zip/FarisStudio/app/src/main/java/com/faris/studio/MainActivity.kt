package com.faris.studio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import com.faris.studio.ui.EditorScreen
import com.faris.studio.ui.FarisTheme

class MainActivity : ComponentActivity() {
    private val vm: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FarisTheme {
                EditorScreen(vm)
            }
        }
    }
}
