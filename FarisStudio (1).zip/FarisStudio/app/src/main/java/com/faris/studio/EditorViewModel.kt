package com.faris.studio

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PointF
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.IntSize
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.faris.studio.core.EditState
import com.faris.studio.core.Exporter
import com.faris.studio.core.Filters
import com.faris.studio.core.ImageLoader
import com.faris.studio.core.PaintLayer
import com.faris.studio.core.PaintOp
import com.faris.studio.core.PaintRenderer
import com.faris.studio.core.ShapeKind
import com.faris.studio.core.ShapeOp
import com.faris.studio.core.StrokeOp
import com.faris.studio.core.TextOp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

enum class Tool(val label: String, val glyph: String, val implemented: Boolean) {
    Select("Select", "▭", false),
    Move("Move", "✛", false),
    Crop("Crop", "✂", false),
    Wand("Magic Wand", "✨", false),
    Brush("Brush", "🖌", true),
    Eraser("Eraser", "⌫", true),
    Fill("Fill", "💧", false),
    Text("Text", "T", true),
    Sticker("Sticker", "☺", false),
    Shape("Shape", "△", true),
    Picker("Picker", "✒", true),
    Hand("Hand", "✋", true)
}

class Command(val undo: () -> Unit, val redo: () -> Unit)

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    // ---------- Document ----------
    var bitmap by mutableStateOf<Bitmap?>(null); private set
    var thumb by mutableStateOf<Bitmap?>(null); private set
    var fileName by mutableStateOf(""); private set
    var loading by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null); private set

    // ---------- Viewport ----------
    var scale by mutableStateOf(1f); private set
    var offset by mutableStateOf(Offset.Zero); private set
    var rotation by mutableStateOf(0f); private set
    var canvasSize by mutableStateOf(IntSize.Zero)

    // ---------- Tools ----------
    var tool by mutableStateOf(Tool.Hand); private set
    var brushColor by mutableStateOf(0xFFFF3B30.toInt())
    var brushFrac by mutableStateOf(0.15f)
    var brushAlpha by mutableStateOf(1f)
    var shapeKind by mutableStateOf(ShapeKind.Rect)
    var shapeFilled by mutableStateOf(false)
    var pendingTextPos by mutableStateOf<PointF?>(null)
    var liveShape by mutableStateOf<ShapeOp?>(null); private set

    // ---------- Edit + layers ----------
    var edit by mutableStateOf(EditState()); private set
    val layers = mutableStateListOf<PaintLayer>()
    var activeLayerId by mutableStateOf(-1); private set
    var bgVisible by mutableStateOf(true)
    var version by mutableIntStateOf(0); private set

    private var nextId = 1
    private var layerCounter = 2
    private var editSnapshot: EditState? = null

    // ---------- History ----------
    private val undoStack = ArrayDeque<Command>()
    private val redoStack = ArrayDeque<Command>()
    private var historyVersion by mutableIntStateOf(0)
    val canUndo: Boolean get() = historyVersion >= 0 && undoStack.isNotEmpty()
    val canRedo: Boolean get() = historyVersion >= 0 && redoStack.isNotEmpty()

    val isDrawTool: Boolean get() = tool == Tool.Brush || tool == Tool.Eraser || tool == Tool.Shape
    val isTapTool: Boolean get() = tool == Tool.Picker || tool == Tool.Text
    val activeLayer: PaintLayer? get() = layers.firstOrNull { it.id == activeLayerId }

    // ---------- Messages ----------
    fun toast(m: String) { message = m }
    fun dismissMessage() { message = null }

    fun selectTool(t: Tool) {
        if (!t.implemented) {
            toast("أداة «${t.label}» غير مفعّلة بعد، قريباً")
        } else {
            tool = t
        }
    }

    // ---------- Open ----------
    fun openImage(uri: Uri) {
        loading = true
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val result = withContext(Dispatchers.IO) {
                try {
                    val bmp = ImageLoader.load(ctx, uri) ?: return@withContext null
                    val s = 160f / max(bmp.width, bmp.height)
                    val th = Bitmap.createScaledBitmap(
                        bmp, max(1, (bmp.width * s).toInt()), max(1, (bmp.height * s).toInt()), true
                    )
                    Triple(bmp, th, ImageLoader.displayName(ctx, uri))
                } catch (e: Throwable) {
                    null
                }
            }
            loading = false
            if (result == null) {
                toast("تعذر فتح الصورة")
                return@launch
            }
            val (bmp, th, name) = result
            try {
                newDocument(bmp)
            } catch (e: OutOfMemoryError) {
                toast("الذاكرة لا تكفي لهذه الصورة")
                return@launch
            }
            thumb = th
            fileName = name
            fit()
        }
    }

    private fun newDocument(bmp: Bitmap) {
        val first = PaintLayer(nextId++, "Layer 1", bmp.width, bmp.height)
        bitmap = bmp
        layers.clear()
        layers.add(first)
        activeLayerId = first.id
        layerCounter = 2
        bgVisible = true
        edit = EditState()
        editSnapshot = null
        pendingTextPos = null
        undoStack.clear()
        redoStack.clear()
        historyVersion++
        version++
    }

    // ---------- Viewport ----------
    fun fit() {
        val b = bitmap ?: return
        if (canvasSize.width == 0 || canvasSize.height == 0) return
        scale = min(canvasSize.width / b.width.toFloat(), canvasSize.height / b.height.toFloat()) * 0.95f
        offset = Offset.Zero
        rotation = 0f
    }

    fun actualSize() { scale = 1f; offset = Offset.Zero }

    fun zoomStep(factor: Float) {
        transform(Offset(canvasSize.width / 2f, canvasSize.height / 2f), Offset.Zero, factor, 0f)
    }

    fun rotateView(deg: Float) {
        val rad = Math.toRadians(deg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        offset = Offset(offset.x * c - offset.y * s, offset.x * s + offset.y * c)
        rotation = (rotation + deg) % 360f
    }

    fun transform(centroid: Offset, pan: Offset, zoom: Float, rotDeg: Float) {
        val center = Offset(canvasSize.width / 2f, canvasSize.height / 2f)
        val newScale = (scale * zoom).coerceIn(MIN_SCALE, MAX_SCALE)
        val z = newScale / scale
        val rad = Math.toRadians(rotDeg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()
        val v = center + offset - centroid
        val rx = (v.x * c - v.y * s) * z
        val ry = (v.x * s + v.y * c) * z
        offset = centroid - center + Offset(rx, ry) + pan
        scale = newScale
        rotation = (rotation + rotDeg) % 360f
    }

    fun screenToImage(p: Offset): Offset {
        val b = bitmap ?: return p
        val c = Offset(canvasSize.width / 2f, canvasSize.height / 2f)
        val v = p - c - offset
        val rad = Math.toRadians(-rotation.toDouble())
        val cs = cos(rad).toFloat()
        val sn = sin(rad).toFloat()
        val rx = v.x * cs - v.y * sn
        val ry = v.x * sn + v.y * cs
        return Offset(rx / scale + b.width / 2f, ry / scale + b.height / 2f)
    }

    // ---------- History ----------
    private fun push(c: Command) {
        undoStack.addLast(c)
        if (undoStack.size > 60) undoStack.removeFirst()
        redoStack.clear()
        historyVersion++
    }

    fun undo() {
        val c = undoStack.removeLastOrNull() ?: return
        c.undo()
        redoStack.addLast(c)
        historyVersion++
        version++
    }

    fun redo() {
        val c = redoStack.removeLastOrNull() ?: return
        c.redo()
        undoStack.addLast(c)
        historyVersion++
        version++
    }

    // ---------- Filters / adjustments ----------
    fun setFilter(id: String) {
        val before = edit
        if (before.filterId == id) return
        val after = before.copy(filterId = id)
        edit = after
        push(Command({ edit = before }, { edit = after }))
    }

    fun previewEdit(n: EditState) {
        if (editSnapshot == null) editSnapshot = edit
        edit = n
    }

    fun commitPreview() {
        val s = editSnapshot ?: return
        editSnapshot = null
        val after = edit
        if (s != after) push(Command({ edit = s }, { edit = after }))
    }

    fun resetEdits() {
        val before = edit
        val after = EditState()
        if (before == after) return
        edit = after
        push(Command({ edit = before }, { edit = after }))
    }

    // ---------- Layers ----------
    fun selectLayer(id: Int) { activeLayerId = id }

    fun toggleBackground() { bgVisible = !bgVisible }

    fun addLayer() {
        val b = bitmap ?: return
        try {
            val l = PaintLayer(nextId++, "Layer ${layerCounter++}", b.width, b.height)
            val prev = activeLayerId
            layers.add(l)
            activeLayerId = l.id
            push(Command(
                undo = {
                    layers.remove(l)
                    activeLayerId = if (layers.any { it.id == prev } || prev == -1) prev else (layers.lastOrNull()?.id ?: -1)
                },
                redo = { layers.add(l); activeLayerId = l.id }
            ))
        } catch (e: OutOfMemoryError) {
            toast("الذاكرة لا تكفي لطبقة جديدة")
        }
    }

    fun deleteActiveLayer() {
        val l = activeLayer
        if (l == null) { toast("لا يمكن حذف الخلفية"); return }
        val idx = layers.indexOf(l)
        layers.removeAt(idx)
        activeLayerId = layers.lastOrNull()?.id ?: -1
        version++
        push(Command(
            undo = { layers.add(min(idx, layers.size), l); activeLayerId = l.id },
            redo = { layers.remove(l); activeLayerId = layers.lastOrNull()?.id ?: -1 }
        ))
    }

    // ---------- Drawing ----------
    private var drawingLayer: PaintLayer? = null
    private var curCanvas: Canvas? = null
    private var curPaint: Paint? = null
    private var strokePts = ArrayList<PointF>()
    private var lastPt: Offset? = null
    private var shapeStart: Offset? = null

    private fun maxDim(): Float {
        val b = bitmap ?: return 1000f
        return max(b.width, b.height).toFloat()
    }

    fun curSize(): Float = maxDim() * (0.002f + brushFrac * 0.08f)
    private fun alphaInt(): Int = (brushAlpha * 255f).toInt().coerceIn(1, 255)

    private fun drawableLayer(): PaintLayer? {
        if (bitmap == null) return null
        val l = activeLayer
        if (l == null) { toast("اختر طبقة رسم (Layer) أولاً، الخلفية للقراءة فقط"); return null }
        if (!l.visible) { toast("الطبقة مخفية"); return null }
        return l
    }

    private fun makeShape(a: Offset, b: Offset) = ShapeOp(
        shapeKind, a.x, a.y, b.x, b.y, brushColor, curSize(), alphaInt(), shapeFilled
    )

    fun beginDraw(screen: Offset) {
        val layer = drawableLayer()
        drawingLayer = layer
        if (layer == null) return
        val p = screenToImage(screen)
        when (tool) {
            Tool.Brush, Tool.Eraser -> {
                strokePts = arrayListOf(PointF(p.x, p.y))
                lastPt = p
                val paint = PaintRenderer.strokePaint(brushColor, curSize(), alphaInt(), tool == Tool.Eraser)
                val canvas = Canvas(layer.bitmap)
                curPaint = paint
                curCanvas = canvas
                canvas.drawPoint(p.x, p.y, paint)
                version++
            }
            Tool.Shape -> {
                shapeStart = p
                liveShape = makeShape(p, p)
            }
            else -> {}
        }
    }

    fun drawTo(screen: Offset) {
        val layer = drawingLayer ?: return
        val p = screenToImage(screen)
        when (tool) {
            Tool.Brush, Tool.Eraser -> {
                val l = lastPt ?: return
                val c = curCanvas ?: return
                val paint = curPaint ?: return
                c.drawLine(l.x, l.y, p.x, p.y, paint)
                strokePts.add(PointF(p.x, p.y))
                lastPt = p
                version++
            }
            Tool.Shape -> liveShape = makeShape(shapeStart ?: p, p)
            else -> {}
        }
        if (layer.bitmap.isRecycled) drawingLayer = null
    }

    fun endDraw() {
        val layer = drawingLayer
        if (layer != null) {
            when (tool) {
                Tool.Brush, Tool.Eraser -> {
                    val eraser = tool == Tool.Eraser
                    val op = StrokeOp(strokePts.toList(), brushColor, curSize(), alphaInt(), eraser)
                    commitOp(layer, op, redraw = !eraser && op.alpha < 255)
                }
                Tool.Shape -> {
                    val s = liveShape
                    if (s != null && hypot(s.x2 - s.x1, s.y2 - s.y1) > 3f) {
                        PaintRenderer.drawOp(Canvas(layer.bitmap), s)
                        commitOp(layer, s, redraw = false)
                    }
                }
                else -> {}
            }
        }
        clearDrawState()
    }

    fun cancelDraw() {
        val layer = drawingLayer
        if (layer != null) {
            PaintRenderer.redraw(layer)
            version++
        }
        clearDrawState()
    }

    private fun clearDrawState() {
        drawingLayer = null
        curCanvas = null
        curPaint = null
        lastPt = null
        shapeStart = null
        liveShape = null
        strokePts = ArrayList()
    }

    private fun commitOp(layer: PaintLayer, op: PaintOp, redraw: Boolean) {
        layer.ops.add(op)
        if (redraw) PaintRenderer.redraw(layer)
        version++
        push(Command(
            undo = {
                if (layer.ops.isNotEmpty()) layer.ops.removeAt(layer.ops.lastIndex)
                PaintRenderer.redraw(layer)
            },
            redo = {
                layer.ops.add(op)
                PaintRenderer.drawOp(Canvas(layer.bitmap), op)
            }
        ))
    }

    fun tap(screen: Offset) {
        val b = bitmap ?: return
        val p = screenToImage(screen)
        val x = p.x.toInt()
        val y = p.y.toInt()
        if (x < 0 || y < 0 || x >= b.width || y >= b.height) return
        when (tool) {
            Tool.Picker -> {
                var color = 0
                var found = false
                for (l in layers.asReversed()) {
                    if (!l.visible) continue
                    val px = l.bitmap.getPixel(x, y)
                    if (android.graphics.Color.alpha(px) > 0) { color = px; found = true; break }
                }
                if (!found) color = b.getPixel(x, y)
                brushColor = color or (0xFF shl 24)
                toast("تم التقاط اللون")
            }
            Tool.Text -> {
                if (drawableLayer() != null) pendingTextPos = PointF(p.x, p.y)
            }
            else -> {}
        }
    }

    fun confirmText(text: String) {
        val pos = pendingTextPos
        pendingTextPos = null
        val t = text.trim()
        if (pos == null || t.isEmpty()) return
        val layer = drawableLayer() ?: return
        val op = TextOp(t, pos.x, pos.y, brushColor, curSize() * 3f, alphaInt())
        PaintRenderer.drawOp(Canvas(layer.bitmap), op)
        commitOp(layer, op, redraw = false)
    }

    // ---------- Export ----------
    private var saving = false

    fun exportPng() {
        val base = bitmap
        if (base == null) { toast("افتح صورة أولاً"); return }
        if (saving) return
        saving = true
        val e = edit
        val ls = layers.toList()
        val bgVis = bgVisible
        toast("جارٍ الحفظ…")
        viewModelScope.launch {
            val ctx = getApplication<Application>()
            val res = withContext(Dispatchers.IO) {
                try {
                    val out = composeBitmap(base, e, ls, bgVis)
                    val r = Exporter.savePng(ctx, out, "FARIS_${System.currentTimeMillis()}")
                    out.recycle()
                    r
                } catch (t: Throwable) {
                    null
                }
            }
            saving = false
            toast(if (res != null) "تم الحفظ: $res" else "فشل الحفظ")
        }
    }

    private fun composeBitmap(base: Bitmap, e: EditState, ls: List<PaintLayer>, bgVis: Boolean): Bitmap {
        val out = Bitmap.createBitmap(base.width, base.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        if (bgVis) {
            val p = Paint(Paint.FILTER_BITMAP_FLAG)
            p.colorFilter = ColorMatrixColorFilter(Filters.finalMatrix(e))
            c.drawBitmap(base, 0f, 0f, p)
            if (e.vignette > 0) {
                c.drawRect(0f, 0f, base.width.toFloat(), base.height.toFloat(),
                    Filters.vignettePaint(base.width, base.height, e.vignette))
            }
        }
        for (l in ls) if (l.visible) c.drawBitmap(l.bitmap, 0f, 0f, null)
        return out
    }

    companion object {
        const val MIN_SCALE = 0.02f
        const val MAX_SCALE = 64f
    }
}
