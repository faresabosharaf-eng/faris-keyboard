package com.faris.studio.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.max
import kotlin.math.min

enum class ShapeKind { Rect, Ellipse, Line }

sealed interface PaintOp

class StrokeOp(
    val pts: List<PointF>, val color: Int, val size: Float, val alpha: Int, val eraser: Boolean
) : PaintOp

class TextOp(
    val text: String, val x: Float, val y: Float, val color: Int, val size: Float, val alpha: Int
) : PaintOp

class ShapeOp(
    val kind: ShapeKind, val x1: Float, val y1: Float, val x2: Float, val y2: Float,
    val color: Int, val stroke: Float, val alpha: Int, val filled: Boolean
) : PaintOp

/** A transparent drawing layer. Its content is the replay of [ops] (so undo is exact). */
class PaintLayer(val id: Int, val name: String, w: Int, h: Int) {
    val bitmap: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val ops = ArrayList<PaintOp>()
    var visible by mutableStateOf(true)
}

object PaintRenderer {
    fun strokePaint(color: Int, size: Float, alpha: Int, eraser: Boolean): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            strokeWidth = size
            if (eraser) {
                xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            } else {
                this.color = color
                this.alpha = alpha
            }
        }

    fun drawOp(c: Canvas, op: PaintOp) {
        when (op) {
            is StrokeOp -> drawStroke(c, op)
            is TextOp -> {
                val p = Paint(Paint.ANTI_ALIAS_FLAG)
                p.color = op.color
                p.alpha = op.alpha
                p.textSize = op.size
                c.drawText(op.text, op.x, op.y, p)
            }
            is ShapeOp -> drawShape(c, op)
        }
    }

    private fun drawStroke(c: Canvas, op: StrokeOp) {
        val pts = op.pts
        if (pts.isEmpty()) return
        val paint = strokePaint(op.color, op.size, op.alpha, op.eraser)
        if (pts.size == 1) {
            c.drawPoint(pts[0].x, pts[0].y, paint)
            return
        }
        val path = Path()
        path.moveTo(pts[0].x, pts[0].y)
        for (i in 1 until pts.size) {
            val p0 = pts[i - 1]
            val p1 = pts[i]
            path.quadTo(p0.x, p0.y, (p0.x + p1.x) / 2f, (p0.y + p1.y) / 2f)
        }
        path.lineTo(pts.last().x, pts.last().y)
        c.drawPath(path, paint)
    }

    private fun drawShape(c: Canvas, op: ShapeOp) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = op.color
        paint.alpha = op.alpha
        paint.strokeWidth = op.stroke
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.style = if (op.filled && op.kind != ShapeKind.Line) Paint.Style.FILL else Paint.Style.STROKE
        val l = min(op.x1, op.x2)
        val t = min(op.y1, op.y2)
        val r = max(op.x1, op.x2)
        val b = max(op.y1, op.y2)
        when (op.kind) {
            ShapeKind.Rect -> c.drawRect(l, t, r, b, paint)
            ShapeKind.Ellipse -> c.drawOval(RectF(l, t, r, b), paint)
            ShapeKind.Line -> c.drawLine(op.x1, op.y1, op.x2, op.y2, paint)
        }
    }

    fun redraw(layer: PaintLayer) {
        layer.bitmap.eraseColor(0)
        val c = Canvas(layer.bitmap)
        for (op in layer.ops) drawOp(c, op)
    }
}
