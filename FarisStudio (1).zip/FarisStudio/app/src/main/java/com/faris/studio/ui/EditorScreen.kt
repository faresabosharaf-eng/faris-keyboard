package com.faris.studio.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.faris.studio.EditorViewModel
import com.faris.studio.Tool
import com.faris.studio.canvas.CanvasView
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

@Composable
fun EditorScreen(vm: EditorViewModel) {
    val wide = LocalConfiguration.current.screenWidthDp >= 720
    var tab by rememberSaveable { mutableStateOf(Tab.Edit) }
    var showSide by rememberSaveable { mutableStateOf(true) }
    var showToolbar by rememberSaveable { mutableStateOf(true) }
    var showAbout by remember { mutableStateOf(false) }
    var showKeys by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.openImage(uri)
    }
    val openImage = { launcher.launch(arrayOf("image/*")) }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }
    LaunchedEffect(vm.message) {
        if (vm.message != null) {
            delay(3500)
            vm.dismissMessage()
        }
    }
    val hasImage = vm.bitmap != null

    Column(
        Modifier
            .fillMaxSize()
            .background(CanvasBg)
            .statusBarsPadding()
            .onKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onKeyEvent false
                val ctrl = e.isCtrlPressed
                when {
                    ctrl && e.key == Key.O -> { openImage(); true }
                    ctrl && e.key == Key.S -> { vm.exportPng(); true }
                    ctrl && e.key == Key.Z && e.isShiftPressed -> { vm.redo(); true }
                    ctrl && e.key == Key.Z -> { vm.undo(); true }
                    ctrl && e.key == Key.Y -> { vm.redo(); true }
                    ctrl && (e.key == Key.Equals || e.key == Key.Plus || e.key == Key.NumPadAdd) -> { vm.zoomStep(1.25f); true }
                    ctrl && (e.key == Key.Minus || e.key == Key.NumPadSubtract) -> { vm.zoomStep(0.8f); true }
                    ctrl && e.key == Key.Zero -> { vm.fit(); true }
                    !ctrl && e.key == Key.B -> { vm.selectTool(Tool.Brush); true }
                    !ctrl && e.key == Key.E -> { vm.selectTool(Tool.Eraser); true }
                    !ctrl && e.key == Key.T -> { vm.selectTool(Tool.Text); true }
                    !ctrl && e.key == Key.U -> { vm.selectTool(Tool.Shape); true }
                    !ctrl && e.key == Key.I -> { vm.selectTool(Tool.Picker); true }
                    !ctrl && e.key == Key.H -> { vm.selectTool(Tool.Hand); true }
                    e.key == Key.F9 -> { showSide = !showSide; true }
                    e.key == Key.F11 -> { val v = !(showSide || showToolbar); showSide = v; showToolbar = v; true }
                    else -> false
                }
            }
            .focusRequester(focus)
            .focusable()
    ) {
        // ---------- Top bar ----------
        Row(
            Modifier.fillMaxWidth().background(BarBg).padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(30.dp).background(Accent, RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                Text("F", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
            }
            Spacer(Modifier.width(8.dp))
            Text(buildAnnotatedString {
                withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.Bold)) { append("FARIS ") }
                withStyle(SpanStyle(color = Accent, fontWeight = FontWeight.Bold)) { append("STUDIO") }
            }, fontSize = 18.sp)
            Spacer(Modifier.weight(1f))
            TopIcon("💾", hasImage) { vm.exportPng() }
            TopIcon("↶", vm.canUndo) { vm.undo() }
            TopIcon("↷", vm.canRedo) { vm.redo() }
            Box {
                TopIcon("⋮", true) { menuOpen = true }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    MenuRow("File ▸ Open Image…  (Ctrl+O)") { menuOpen = false; openImage() }
                    MenuRow("File ▸ Export PNG  (Ctrl+S)", hasImage) { menuOpen = false; vm.exportPng() }
                    HorizontalDivider()
                    MenuRow("View ▸ Zoom In", hasImage) { menuOpen = false; vm.zoomStep(1.25f) }
                    MenuRow("View ▸ Zoom Out", hasImage) { menuOpen = false; vm.zoomStep(0.8f) }
                    MenuRow("View ▸ Fit Screen", hasImage) { menuOpen = false; vm.fit() }
                    MenuRow("View ▸ Actual Pixels (100%)", hasImage) { menuOpen = false; vm.actualSize() }
                    MenuRow("View ▸ Rotate View 90°", hasImage) { menuOpen = false; vm.rotateView(90f) }
                    HorizontalDivider()
                    MenuRow((if (showToolbar) "✓ " else "") + "Window ▸ Toolbar") { menuOpen = false; showToolbar = !showToolbar }
                    MenuRow((if (showSide) "✓ " else "") + "Window ▸ Side panels (tablet)") { menuOpen = false; showSide = !showSide }
                    HorizontalDivider()
                    MenuRow("Help ▸ Keyboard Shortcuts") { menuOpen = false; showKeys = true }
                    MenuRow("Help ▸ About FARIS STUDIO") { menuOpen = false; showAbout = true }
                }
            }
        }

        // ---------- Tabs ----------
        Row(
            Modifier.fillMaxWidth().background(BarBg).horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Tab.values().forEach { t ->
                val sel = t == tab
                Row(
                    Modifier
                        .background(if (sel) Selected else Color.Transparent, RoundedCornerShape(20.dp))
                        .clickable { tab = t }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(t.glyph, fontSize = 14.sp)
                    Spacer(Modifier.width(6.dp))
                    Text(t.label, fontSize = 13.sp, color = if (sel) Color.White else TextDim)
                }
            }
        }

        // ---------- Workspace ----------
        Row(Modifier.weight(1f).fillMaxWidth()) {
            if (showToolbar) {
                Column(
                    Modifier.fillMaxHeight().width(62.dp).background(PanelBg)
                        .verticalScroll(rememberScrollState()).padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Tool.values().forEach { t -> ToolButton(t, vm.tool == t) { vm.selectTool(t) } }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    CanvasView(vm)
                    if (!hasImage && !vm.loading) {
                        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("FARIS STUDIO", color = Accent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = { openImage() }) { Text("Open Image") }
                        }
                    }
                    if (vm.loading) CircularProgressIndicator(Modifier.align(Alignment.Center))
                    vm.message?.let { m ->
                        Text(
                            m, fontSize = 13.sp, color = Color.White,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(10.dp)
                                .background(Color(0xDD000000), RoundedCornerShape(16.dp))
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
                Box(
                    Modifier.fillMaxWidth().background(PanelBg).heightIn(max = 190.dp)
                        .verticalScroll(rememberScrollState()).padding(8.dp)
                ) { BottomPanel(vm, tab) }
            }
            if (wide && showSide) {
                SidePanel(
                    vm,
                    Modifier.fillMaxHeight().width(280.dp).background(CanvasBg)
                        .verticalScroll(rememberScrollState()).padding(8.dp)
                )
            }
        }

        // ---------- Bottom bar ----------
        Row(
            Modifier.fillMaxWidth().background(BarBg).navigationBarsPadding().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            OutlinedButton(onClick = { vm.resetEdits() }, enabled = hasImage, contentPadding = PaddingValues(horizontal = 10.dp)) {
                Text("↺ Reset", fontSize = 12.sp)
            }
            Spacer(Modifier.weight(1f))
            BarIcon("−", hasImage) { vm.zoomStep(0.8f) }
            Text(
                "${(vm.scale * 100).roundToInt()}%", fontSize = 13.sp,
                modifier = Modifier.clickable(enabled = hasImage) { vm.actualSize() }.padding(horizontal = 4.dp)
            )
            BarIcon("+", hasImage) { vm.zoomStep(1.25f) }
            TextButton(onClick = { vm.fit() }, enabled = hasImage, contentPadding = PaddingValues(horizontal = 8.dp)) {
                Text("⛶ Fit", fontSize = 12.sp)
            }
            Spacer(Modifier.weight(1f))
            Button(onClick = { vm.exportPng() }, enabled = hasImage, contentPadding = PaddingValues(horizontal = 14.dp)) {
                Text("💾 Save", fontSize = 13.sp)
            }
        }
    }

    // ---------- Dialogs ----------
    if (vm.pendingTextPos != null) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { vm.pendingTextPos = null },
            confirmButton = { TextButton(onClick = { vm.confirmText(text) }) { Text("OK") } },
            dismissButton = { TextButton(onClick = { vm.pendingTextPos = null }) { Text("Cancel") } },
            title = { Text("Text") },
            text = {
                OutlinedTextField(value = text, onValueChange = { text = it }, modifier = Modifier.fillMaxWidth())
            }
        )
    }
    if (showAbout) {
        AlertDialog(
            onDismissRequest = { showAbout = false },
            confirmButton = { TextButton(onClick = { showAbout = false }) { Text("OK") } },
            title = { Text("FARIS STUDIO") },
            text = {
                Text("Version 0.2.0\nواجهة جديدة، طبقات رسم، فرشاة ومحاة وأشكال ونصوص، فلاتر وتعديلات، تراجع/إعادة، وحفظ PNG.")
            }
        )
    }
    if (showKeys) {
        AlertDialog(
            onDismissRequest = { showKeys = false },
            confirmButton = { TextButton(onClick = { showKeys = false }) { Text("OK") } },
            title = { Text("Keyboard Shortcuts") },
            text = {
                Text(
                    "Ctrl+O  فتح صورة\nCtrl+S  حفظ PNG\nCtrl+Z  تراجع\nCtrl+Y / Ctrl+Shift+Z  إعادة\n" +
                        "Ctrl +/-/0  زوم / ملاءمة\nB فرشاة  E ممحاة  T نص\nU شكل  I ملتقط ألوان  H يد\n" +
                        "F9 اللوحات الجانبية  F11 إخفاء الكل\nعجلة الفأرة: زوم"
                )
            }
        )
    }
}

@Composable
private fun TopIcon(glyph: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).alpha(if (enabled) 1f else 0.35f).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(glyph, fontSize = 20.sp) }
}

@Composable
private fun BarIcon(glyph: String, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).alpha(if (enabled) 1f else 0.35f)
            .background(PanelBg, RoundedCornerShape(17.dp)).clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(glyph, fontSize = 18.sp) }
}

@Composable
private fun MenuRow(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(text, fontSize = 14.sp) }, enabled = enabled, onClick = onClick)
}

@Composable
private fun ToolButton(t: Tool, selected: Boolean, onClick: () -> Unit) {
    Column(
        Modifier.padding(vertical = 2.dp).width(54.dp)
            .alpha(if (t.implemented) 1f else 0.4f)
            .background(if (selected) Selected else Color.Transparent, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(t.glyph, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(t.label, fontSize = 10.sp, textAlign = TextAlign.Center, lineHeight = 11.sp, color = if (selected) Color.White else TextDim)
    }
}
