package com.faris.studio.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.faris.studio.EditorViewModel
import com.faris.studio.Tool
import com.faris.studio.core.FilterPreset
import com.faris.studio.core.Filters
import com.faris.studio.core.ShapeKind
import kotlin.math.roundToInt

enum class Tab(val label: String, val glyph: String) {
    Edit("Edit", "🖼"),
    Filters("Filters", "✨"),
    Adjust("Adjust", "⚙"),
    Effects("Effects", "★"),
    Colors("Colors", "🎨"),
    More("More", "⊞")
}

@Composable
fun LabeledSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueText: String,
    onChange: (Float) -> Unit, onDone: () -> Unit = {}, modifier: Modifier = Modifier
) {
    Column(modifier) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, fontSize = 12.sp, color = TextDim)
            Text(valueText, fontSize = 12.sp)
        }
        Slider(
            value = value, onValueChange = onChange, onValueChangeFinished = onDone, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent)
        )
    }
}

@Composable
fun AdjustSliders(vm: EditorViewModel) {
    val e = vm.edit
    Column {
        LabeledSlider("Brightness", e.brightness.toFloat(), -100f..100f, "${e.brightness}",
            { vm.previewEdit(e.copy(brightness = it.roundToInt())) }, { vm.commitPreview() })
        LabeledSlider("Contrast", e.contrast.toFloat(), -100f..100f, "${e.contrast}",
            { vm.previewEdit(e.copy(contrast = it.roundToInt())) }, { vm.commitPreview() })
        LabeledSlider("Saturation", e.saturation.toFloat(), -100f..100f, "${e.saturation}",
            { vm.previewEdit(e.copy(saturation = it.roundToInt())) }, { vm.commitPreview() })
        LabeledSlider("Hue", e.hue.toFloat(), -180f..180f, "${e.hue}",
            { vm.previewEdit(e.copy(hue = it.roundToInt())) }, { vm.commitPreview() })
    }
}

@Composable
fun FilterTile(vm: EditorViewModel, p: FilterPreset, modifier: Modifier = Modifier) {
    val sel = vm.edit.filterId == p.id
    Column(
        modifier
            .clip(RoundedCornerShape(8.dp))
            .border(2.dp, if (sel) Accent else Color.Transparent, RoundedCornerShape(8.dp))
            .clickable { vm.setFilter(p.id) }
            .padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val t = vm.thumb
        if (t != null) {
            Image(
                bitmap = t.asImageBitmap(),
                contentDescription = p.label,
                contentScale = ContentScale.Crop,
                colorFilter = ColorFilter.colorMatrix(ColorMatrix(Filters.presetArray(p))),
                modifier = Modifier.fillMaxWidth().aspectRatio(1.25f).clip(RoundedCornerShape(6.dp))
            )
        } else {
            Box(Modifier.fillMaxWidth().aspectRatio(1.25f).background(BarBg, RoundedCornerShape(6.dp)))
        }
        Text(p.label, fontSize = 11.sp, maxLines = 1, color = if (sel) Accent else TextDim)
    }
}

@Composable
fun FilterGrid(vm: EditorViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Filters.sidePresets.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { FilterTile(vm, it, Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
fun LooksStrip(vm: EditorViewModel) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(Filters.looks) { FilterTile(vm, it, Modifier.width(84.dp)) }
    }
}

@Composable
private fun LayerRow(
    name: String, visible: Boolean, selected: Boolean, locked: Boolean,
    onToggle: () -> Unit, onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(if (selected) Selected else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("👁", fontSize = 18.sp,
            modifier = Modifier.alpha(if (visible) 1f else 0.3f).clickable(onClick = onToggle).padding(4.dp))
        Spacer(Modifier.width(10.dp))
        Text(name, fontSize = 14.sp, modifier = Modifier.weight(1f))
        if (locked) Text("🔒", fontSize = 14.sp)
    }
}

@Composable
fun LayersPanel(vm: EditorViewModel) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(BarBg)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Layers", fontSize = 15.sp, color = Accent, modifier = Modifier.weight(1f))
            Text("🗑", fontSize = 18.sp, modifier = Modifier.clickable { vm.deleteActiveLayer() }.padding(8.dp))
            Text("＋", fontSize = 22.sp, color = Accent, modifier = Modifier.clickable { vm.addLayer() }.padding(horizontal = 8.dp))
        }
        vm.layers.asReversed().forEach { l ->
            LayerRow(l.name, l.visible, vm.activeLayerId == l.id, false,
                onToggle = { l.visible = !l.visible }, onClick = { vm.selectLayer(l.id) })
        }
        LayerRow("Background", vm.bgVisible, vm.activeLayerId == -1, true,
            onToggle = { vm.toggleBackground() }, onClick = { vm.selectLayer(-1) })
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(BarBg).padding(10.dp)) {
        Text(title, fontSize = 15.sp, color = Accent)
        Spacer(Modifier.height(8.dp))
        content()
    }
}

@Composable
fun SidePanel(vm: EditorViewModel, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        LayersPanel(vm)
        Section("Filters") { FilterGrid(vm) }
        Section("Adjustments") { AdjustSliders(vm) }
    }
}

private val palette = listOf(
    0xFF000000, 0xFFFFFFFF, 0xFF8E8E93, 0xFFFF3B30, 0xFFFF9500, 0xFFFFCC00, 0xFF34C759, 0xFF00C7BE, 0xFF1E7BFF, 0xFF5856D6,
    0xFFAF52DE, 0xFFFF2D55, 0xFFA2845E, 0xFF7A1F1F, 0xFFFFD9B3, 0xFFB6F0B6, 0xFFB3E5FF, 0xFFD7C4FF, 0xFF1C1C1E, 0xFF3A3A3C
)

@Composable
private fun ColorBox(color: Int, size: Int = 28) {
    Box(Modifier.size(size.dp).background(Color(color), RoundedCornerShape(6.dp)).border(1.dp, TextDim, RoundedCornerShape(6.dp)))
}

@Composable
fun ColorsPanel(vm: EditorViewModel) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        palette.chunked(10).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { c ->
                    val argb = Color(c).toArgb()
                    Box(
                        Modifier.weight(1f).aspectRatio(1f).padding(2.dp)
                            .background(Color(c), RoundedCornerShape(6.dp))
                            .border(if (vm.brushColor == argb) 3.dp else 1.dp,
                                if (vm.brushColor == argb) Accent else TextDim, RoundedCornerShape(6.dp))
                            .clickable { vm.brushColor = argb }
                    )
                }
            }
        }
    }
}

@Composable
fun OptionsPanel(vm: EditorViewModel) {
    val t = vm.tool
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        when (t) {
            Tool.Brush, Tool.Eraser, Tool.Shape, Tool.Text -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(t.label, fontSize = 14.sp, color = Accent, modifier = Modifier.weight(1f))
                    if (t != Tool.Eraser) ColorBox(vm.brushColor)
                }
                if (t == Tool.Shape) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        ShapeKind.values().forEach { k ->
                            FilterChip(selected = vm.shapeKind == k, onClick = { vm.shapeKind = k },
                                label = { Text(k.name, fontSize = 12.sp) })
                        }
                        FilterChip(selected = vm.shapeFilled, onClick = { vm.shapeFilled = !vm.shapeFilled },
                            label = { Text("Fill", fontSize = 12.sp) })
                    }
                }
                LabeledSlider(if (t == Tool.Shape) "Stroke" else "Size", vm.brushFrac, 0f..1f,
                    "${vm.curSize().roundToInt()} px", { vm.brushFrac = it })
                if (t != Tool.Eraser) {
                    LabeledSlider("Opacity", vm.brushAlpha, 0.05f..1f, "${(vm.brushAlpha * 100).roundToInt()}%",
                        { vm.brushAlpha = it })
                }
                if (t == Tool.Text) Text("اضغط على الصورة لكتابة نص", fontSize = 12.sp, color = TextDim)
                if (t != Tool.Eraser) Text("اللون من تبويب Colors", fontSize = 11.sp, color = TextDim)
            }
            Tool.Picker -> {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Picker", fontSize = 14.sp, color = Accent, modifier = Modifier.weight(1f))
                    ColorBox(vm.brushColor)
                }
                Text("اضغط على أي نقطة بالصورة لالتقاط لونها", fontSize = 12.sp, color = TextDim)
            }
            else -> {
                Text("Hand", fontSize = 14.sp, color = Accent)
                Text("حرّك الصورة بإصبع، وكبّر بإصبعين. الرسم بالفرشاة على طبقة Layer.", fontSize = 12.sp, color = TextDim)
            }
        }
    }
}

@Composable
fun EffectsPanel(vm: EditorViewModel) {
    val e = vm.edit
    Column {
        LabeledSlider("Vignette", e.vignette.toFloat(), 0f..100f, "${e.vignette}",
            { vm.previewEdit(e.copy(vignette = it.roundToInt())) }, { vm.commitPreview() })
        Text("مؤثرات أخرى (Blur, Grain, Glow) تأتي بمراحل لاحقة.", fontSize = 11.sp, color = TextDim)
    }
}

@Composable
fun BottomPanel(vm: EditorViewModel, tab: Tab) {
    when (tab) {
        Tab.Edit -> OptionsPanel(vm)
        Tab.Filters -> LooksStrip(vm)
        Tab.Adjust -> AdjustSliders(vm)
        Tab.Effects -> EffectsPanel(vm)
        Tab.Colors -> ColorsPanel(vm)
        Tab.More -> LayersPanel(vm)
    }
}
