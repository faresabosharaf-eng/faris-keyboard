package com.faris.studio.canvas

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateRotation
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawStyle
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import com.faris.studio.EditorViewModel
import com.faris.studio.Tool
import com.faris.studio.core.Filters
import com.faris.studio.core.ShapeKind
import com.faris.studio.ui.Accent
import com.faris.studio.ui.CanvasBg
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.pow

@Composable
fun CanvasView(vm: EditorViewModel, modifier: Modifier = Modifier) {
    val base = vm.bitmap
    val baseImage = remember(base) { base?.asImageBitmap() }
    val colorFilter = remember(vm.edit) {
        ColorFilter.colorMatrix(ColorMatrix(Filters.finalMatrix(vm.edit).array.copyOf()))
    }

    Box(
        modifier
            .fillMaxSize()
            .clipToBounds()
            .onSizeChanged { vm.canvasSize = it }
            // One finger: draw / pan / tap tool.  Two fingers: pinch-zoom, pan, rotate view.
            .pointerInput(vm.tool) {
                val slop = viewConfiguration.touchSlop
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val hasImage = vm.bitmap != null
                    var drawing = false
                    var multi = false
                    var moved = false
                    if (hasImage && vm.isDrawTool) {
                        vm.beginDraw(down.position)
                        drawing = true
                    }
                    do {
                        val ev = awaitPointerEvent()
                        val pressed = ev.changes.count { it.pressed }
                        if (pressed >= 2) {
                            if (drawing) { vm.cancelDraw(); drawing = false }
                            multi = true
                            if (hasImage) {
                                vm.transform(
                                    ev.calculateCentroid(useCurrent = false),
                                    ev.calculatePan(), ev.calculateZoom(), ev.calculateRotation()
                                )
                            }
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        } else if (pressed == 1) {
                            val ch = ev.changes.firstOrNull { it.pressed }
                            if (ch != null) {
                                if ((ch.position - down.position).getDistance() > slop) moved = true
                                if (drawing) {
                                    vm.drawTo(ch.position)
                                    ch.consume()
                                } else if (hasImage && vm.tool == Tool.Hand) {
                                    vm.transform(ch.position, ch.positionChange(), 1f, 0f)
                                    ch.consume()
                                }
                            }
                        }
                    } while (ev.changes.any { it.pressed })
                    if (drawing) {
                        vm.endDraw()
                    } else if (hasImage && vm.isTapTool && !multi && !moved) {
                        vm.tap(down.position)
                    }
                }
            }
            // Mouse wheel zoom
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val ev = awaitPointerEvent()
                        if (ev.type == PointerEventType.Scroll && vm.bitmap != null) {
                            val ch = ev.changes.first()
                            vm.transform(ch.position, Offset.Zero, 1.15f.pow(-ch.scrollDelta.y), 0f)
                            ch.consume()
                        }
                    }
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            @Suppress("UNUSED_VARIABLE")
            val tick = vm.version // redraw when pixels change
            drawRect(CanvasBg)
            val img = baseImage ?: return@Canvas
            val w = img.width.toFloat()
            val h = img.height.toFloat()
            val s = vm.scale
            val quality = when {
                s >= 4f -> FilterQuality.None
                s >= 1f -> FilterQuality.Low
                else -> FilterQuality.High
            }
            withTransform({
                translate(left = size.width / 2f + vm.offset.x, top = size.height / 2f + vm.offset.y)
                rotate(vm.rotation, Offset.Zero)
                scale(s, s, Offset.Zero)
                translate(left = -w / 2f, top = -h / 2f)
            }) {
                if (vm.bgVisible) {
                    drawImage(image = img, colorFilter = colorFilter, filterQuality = quality)
                    if (vm.edit.vignette > 0) {
                        val a = vm.edit.vignette / 100f * 0.85f
                        drawRect(
                            brush = Brush.radialGradient(
                                0.55f to Color.Transparent,
                                1f to Color.Black.copy(alpha = a),
                                center = Offset(w / 2f, h / 2f),
                                radius = hypot(w, h) / 2f
                            ),
                            size = Size(w, h)
                        )
                    }
                } else {
                    drawRect(Color(0x22FFFFFF), size = Size(w, h))
                }
                for (l in vm.layers) {
                    if (l.visible) drawImage(image = l.bitmap.asImageBitmap(), filterQuality = quality)
                }
                vm.liveShape?.let { op ->
                    val c = Color(op.color).copy(alpha = op.alpha / 255f)
                    val style: DrawStyle =
                        if (op.filled && op.kind != ShapeKind.Line) Fill else Stroke(width = op.stroke)
                    val tl = Offset(min(op.x1, op.x2), min(op.y1, op.y2))
                    val sz = Size(abs(op.x2 - op.x1), abs(op.y2 - op.y1))
                    when (op.kind) {
                        ShapeKind.Rect -> drawRect(c, tl, sz, style = style)
                        ShapeKind.Ellipse -> drawOval(c, tl, sz, style = style)
                        ShapeKind.Line -> drawLine(
                            c, Offset(op.x1, op.y1), Offset(op.x2, op.y2),
                            strokeWidth = op.stroke, cap = StrokeCap.Round
                        )
                    }
                }
                drawRect(Accent, size = Size(w, h), style = Stroke(width = 2f / s))
            }
        }
    }
}
