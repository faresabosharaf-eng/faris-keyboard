package com.faris.studio.core

import android.graphics.Color as AColor
import android.graphics.ColorMatrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Non-destructive edit parameters for the background photo. */
data class EditState(
    val filterId: String = "normal",
    val brightness: Int = 0,   // -100..100
    val contrast: Int = 0,     // -100..100
    val saturation: Int = 0,   // -100..100
    val hue: Int = 0,          // -180..180
    val vignette: Int = 0      // 0..100
)

class FilterPreset(val id: String, val label: String, val build: () -> ColorMatrix)

object Filters {
    private fun sat(s: Float) = ColorMatrix().apply { setSaturation(s) }

    private fun scaleRGB(r: Float, g: Float, b: Float, t: Float = 0f) = ColorMatrix(
        floatArrayOf(
            r, 0f, 0f, 0f, t,
            0f, g, 0f, 0f, t,
            0f, 0f, b, 0f, t,
            0f, 0f, 0f, 1f, 0f
        )
    )

    private fun contrast(c: Float): ColorMatrix {
        val t = 128f * (1f - c)
        return ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }

    private fun bright(b: Float) = ColorMatrix(
        floatArrayOf(
            1f, 0f, 0f, 0f, b,
            0f, 1f, 0f, 0f, b,
            0f, 0f, 1f, 0f, b,
            0f, 0f, 0f, 1f, 0f
        )
    )

    private fun hue(deg: Float): ColorMatrix {
        val r = Math.toRadians(deg.toDouble())
        val c = cos(r).toFloat()
        val s = sin(r).toFloat()
        return ColorMatrix(
            floatArrayOf(
                0.213f + c * 0.787f - s * 0.213f, 0.715f - c * 0.715f - s * 0.715f, 0.072f - c * 0.072f + s * 0.928f, 0f, 0f,
                0.213f - c * 0.213f + s * 0.143f, 0.715f + c * 0.285f + s * 0.140f, 0.072f - c * 0.072f - s * 0.283f, 0f, 0f,
                0.213f - c * 0.213f - s * 0.787f, 0.715f - c * 0.715f + s * 0.715f, 0.072f + c * 0.928f + s * 0.072f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }

    /** Applies matrices in the given order (first argument first). */
    private fun chain(vararg ms: ColorMatrix): ColorMatrix {
        val r = ColorMatrix()
        for (m in ms) r.postConcat(m)
        return r
    }

    private val sepiaM = floatArrayOf(
        0.393f, 0.769f, 0.189f, 0f, 0f,
        0.349f, 0.686f, 0.168f, 0f, 0f,
        0.272f, 0.534f, 0.131f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    )

    val normal = FilterPreset("normal", "Normal") { ColorMatrix() }
    val vintage = FilterPreset("vintage", "Vintage") { chain(sat(0.7f), scaleRGB(1.08f, 1.0f, 0.85f, 6f), contrast(0.92f)) }
    val bw = FilterPreset("bw", "Black & White") { sat(0f) }
    val sepia = FilterPreset("sepia", "Sepia") { ColorMatrix(sepiaM.copyOf()) }
    val cool = FilterPreset("cool", "Cool") { scaleRGB(0.9f, 1f, 1.15f) }
    val warm = FilterPreset("warm", "Warm") { scaleRGB(1.12f, 1.02f, 0.88f) }

    val nature = FilterPreset("nature", "Nature") { chain(sat(1.25f), contrast(1.08f)) }
    val urban = FilterPreset("urban", "Urban") { chain(sat(0.75f), contrast(1.25f)) }
    val dream = FilterPreset("dream", "Dream") { chain(sat(1.1f), scaleRGB(1.05f, 1f, 1.08f, 12f), contrast(0.92f)) }
    val retro = FilterPreset("retro", "Retro") { chain(sat(0.8f), scaleRGB(1.1f, 1.0f, 0.8f, 8f), contrast(1.05f)) }
    val mono = FilterPreset("mono", "Mono") { chain(sat(0f), contrast(1.25f)) }
    val vivid = FilterPreset("vivid", "Vivid") { chain(sat(1.6f), contrast(1.12f)) }
    val sunset = FilterPreset("sunset", "Sunset") { chain(sat(1.2f), scaleRGB(1.2f, 1.0f, 0.8f)) }
    val film = FilterPreset("film", "Film") { chain(sat(0.85f), scaleRGB(0.98f, 1.04f, 1.0f, 4f), contrast(1.15f)) }

    val sidePresets = listOf(normal, vintage, bw, sepia, cool, warm)
    val looks = listOf(nature, urban, dream, retro, mono, vivid, sunset, film)
    private val all = sidePresets + looks

    fun presetArray(p: FilterPreset): FloatArray = p.build().array.copyOf()

    /** Preset + adjustments, as one color matrix. */
    fun finalMatrix(e: EditState): ColorMatrix {
        val preset = (all.firstOrNull { it.id == e.filterId } ?: normal).build()
        val cScale = (1f + e.contrast / 100f).coerceAtLeast(0f)
        return chain(
            preset,
            sat((1f + e.saturation / 100f).coerceAtLeast(0f)),
            hue(e.hue.toFloat()),
            contrast(cScale),
            bright(e.brightness * 2.55f)
        )
    }

    fun vignettePaint(w: Int, h: Int, strength: Int): Paint {
        val a = (strength / 100f * 0.85f * 255f).toInt().coerceIn(0, 255)
        val r = hypot(w.toFloat(), h.toFloat()) / 2f
        return Paint().apply {
            shader = RadialGradient(
                w / 2f, h / 2f, r,
                intArrayOf(0, AColor.argb(a, 0, 0, 0)),
                floatArrayOf(0.55f, 1f),
                Shader.TileMode.CLAMP
            )
        }
    }
}
